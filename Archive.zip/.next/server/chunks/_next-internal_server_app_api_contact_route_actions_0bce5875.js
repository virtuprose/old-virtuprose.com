module.exports=[29216,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_contact_route_actions_0bce5875.js.map