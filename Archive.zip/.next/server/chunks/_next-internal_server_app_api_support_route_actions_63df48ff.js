module.exports=[93373,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_support_route_actions_63df48ff.js.map