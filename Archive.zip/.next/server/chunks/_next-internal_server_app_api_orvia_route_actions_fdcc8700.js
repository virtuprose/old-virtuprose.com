module.exports=[18849,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_orvia_route_actions_fdcc8700.js.map