module.exports=[73846,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_custom-pricing_route_actions_773aa9aa.js.map