module.exports=[83266,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_terms_page_actions_3b82705a.js.map