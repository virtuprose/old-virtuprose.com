module.exports=[25790,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_faq_page_actions_15af725e.js.map