module.exports=[88710,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_examples_page_actions_a7432a91.js.map