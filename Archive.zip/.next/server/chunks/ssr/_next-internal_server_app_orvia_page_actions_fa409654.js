module.exports=[50036,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_orvia_page_actions_fa409654.js.map