module.exports=[97630,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_refund_page_actions_d0cb8c23.js.map