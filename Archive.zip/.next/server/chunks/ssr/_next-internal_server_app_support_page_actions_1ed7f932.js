module.exports=[60810,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_support_page_actions_1ed7f932.js.map