module.exports=[52140,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_demo_page_actions_0903ddc0.js.map