module.exports=[48228,a=>{"use strict";var b=a.i(87924);function c(){return(0,b.jsx)("div",{id:"examples",className:"container h-px"})}a.s(["default",()=>c])}];

//# sourceMappingURL=src_app_examples_page_tsx_4c3876a1._.js.map