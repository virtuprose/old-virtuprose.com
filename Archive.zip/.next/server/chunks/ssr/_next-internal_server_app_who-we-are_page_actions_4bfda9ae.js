module.exports=[95503,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_who-we-are_page_actions_4bfda9ae.js.map