var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/custom-pricing/route.js")
R.c("server/chunks/[root-of-the-server]__25848bbb._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__0092b9ee._.js")
R.c("server/chunks/_next-internal_server_app_api_custom-pricing_route_actions_773aa9aa.js")
R.m(15800)
module.exports=R.m(15800).exports
