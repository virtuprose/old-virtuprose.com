var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/support/route.js")
R.c("server/chunks/[root-of-the-server]__67d1fa9e._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__0092b9ee._.js")
R.c("server/chunks/_next-internal_server_app_api_support_route_actions_63df48ff.js")
R.m(48141)
module.exports=R.m(48141).exports
