var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orvia/route.js")
R.c("server/chunks/[root-of-the-server]__cadba808._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_f5b4c8f8.js")
R.c("server/chunks/[root-of-the-server]__0092b9ee._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_orvia_route_actions_fdcc8700.js")
R.m(57889)
module.exports=R.m(57889).exports
