var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/[root-of-the-server]__8616b82b._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__0092b9ee._.js")
R.c("server/chunks/_next-internal_server_app_api_contact_route_actions_0bce5875.js")
R.m(86590)
module.exports=R.m(86590).exports
