globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/68453a8be5c3bf45.js",
    "static/chunks/12c9f11ee74753f4.js",
    "static/chunks/ea83129e4b57515b.js",
    "static/chunks/284c2b28626b776c.js",
    "static/chunks/turbopack-ce77d0a33d712416.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];