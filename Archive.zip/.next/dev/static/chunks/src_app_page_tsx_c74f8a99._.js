(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_ff2ca597._.js",
  "static/chunks/src_app_page_tsx_b4090435._.js"
],
    source: "dynamic"
});
