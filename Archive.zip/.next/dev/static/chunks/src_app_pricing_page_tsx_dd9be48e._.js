(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_f6c33770._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_f086bc19._.js"
],
    source: "dynamic"
});
