(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__048517db._.css",
  "static/chunks/src_c4194649._.js",
  "static/chunks/node_modules_next_c8525d27._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_lottie-web_build_player_lottie_576e9750.js",
  "static/chunks/node_modules_bcb11845._.js"
],
    source: "dynamic"
});
