(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/orvia-demo-widget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OrviaDemoWidget",
    ()=>OrviaDemoWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
const initialMessages = [
    {
        id: 1,
        sender: "orvia",
        text: "Hi! I'm Orvia. Want to book a demo or check availability?"
    },
    {
        id: 2,
        sender: "user",
        text: "Show me open slots this week."
    },
    {
        id: 3,
        sender: "orvia",
        text: "You have Tuesday 11:00 AM PT or Wednesday 3:30 PM PT. Pick one and I’ll invite your team."
    }
];
const replyMap = [
    {
        match: /price|cost|plan/i,
        reply: "Pricing starts at $49/mo for Starter and scales with channels & usage. Want me to send the full matrix?"
    },
    {
        match: /book|slot|meeting|demo/i,
        reply: "I can book you instantly. Just tell me a time and I’ll drop a calendar invite + payment link if needed."
    },
    {
        match: /integration|crm|api/i,
        reply: "Orvia connects to HubSpot, Salesforce, Zapier, Stripe, Razorpay, and custom APIs. Need a specific integration?"
    }
];
let idCounter = initialMessages.length + 1;
function OrviaDemoWidget() {
    _s();
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialMessages);
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [isTyping, setIsTyping] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    function getReply(text) {
        const found = replyMap.find((entry)=>entry.match.test(text));
        return found?.reply ?? "On it! I can answer questions, book appointments, and take payments. Ask me anything about launching Orvia.";
    }
    function handleSubmit(event) {
        event.preventDefault();
        if (!input.trim()) return;
        const trimmed = input.trim();
        setMessages((prev)=>[
                ...prev,
                {
                    id: ++idCounter,
                    sender: "user",
                    text: trimmed
                }
            ]);
        setInput("");
        setIsTyping(true);
        const reply = getReply(trimmed);
        window.setTimeout(()=>{
            setMessages((prev)=>[
                    ...prev,
                    {
                        id: ++idCounter,
                        sender: "orvia",
                        text: reply
                    }
                ]);
            setIsTyping(false);
        }, 800);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "demo-widget",
        "aria-live": "polite",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "demo-widget-header",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "dot",
                        "aria-hidden": "true"
                    }, void 0, false, {
                        fileName: "[project]/src/components/orvia-demo-widget.tsx",
                        lineNumber: 69,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "Orvia widget"
                            }, void 0, false, {
                                fileName: "[project]/src/components/orvia-demo-widget.tsx",
                                lineNumber: 71,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                children: "WhatsApp · Web · App"
                            }, void 0, false, {
                                fileName: "[project]/src/components/orvia-demo-widget.tsx",
                                lineNumber: 72,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/orvia-demo-widget.tsx",
                        lineNumber: 70,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/orvia-demo-widget.tsx",
                lineNumber: 68,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "demo-messages",
                children: [
                    messages.map((message)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `demo-message ${message.sender}`,
                            children: message.text
                        }, message.id, false, {
                            fileName: "[project]/src/components/orvia-demo-widget.tsx",
                            lineNumber: 77,
                            columnNumber: 11
                        }, this)),
                    isTyping ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "demo-message typing",
                        children: "Orvia is typing…"
                    }, void 0, false, {
                        fileName: "[project]/src/components/orvia-demo-widget.tsx",
                        lineNumber: 81,
                        columnNumber: 21
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/orvia-demo-widget.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                className: "demo-input",
                onSubmit: handleSubmit,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        placeholder: "Ask Orvia about bookings, pricing, or integrations…",
                        value: input,
                        onChange: (event)=>setInput(event.target.value),
                        "aria-label": "Send a message to the Orvia demo widget"
                    }, void 0, false, {
                        fileName: "[project]/src/components/orvia-demo-widget.tsx",
                        lineNumber: 84,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        children: "Send"
                    }, void 0, false, {
                        fileName: "[project]/src/components/orvia-demo-widget.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/orvia-demo-widget.tsx",
                lineNumber: 83,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/orvia-demo-widget.tsx",
        lineNumber: 67,
        columnNumber: 5
    }, this);
}
_s(OrviaDemoWidget, "in1GAClQL0GdLygzrBYozMmXfGM=");
_c = OrviaDemoWidget;
var _c;
__turbopack_context__.k.register(_c, "OrviaDemoWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_components_orvia-demo-widget_tsx_4ada6184._.js.map