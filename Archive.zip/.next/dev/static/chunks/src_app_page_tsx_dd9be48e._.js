(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_397aff1f._.js",
  "static/chunks/node_modules_gsap_f48a6384._.js",
  "static/chunks/node_modules_three_build_three_core_996ef05a.js",
  "static/chunks/node_modules_three_build_three_module_0c59ee63.js",
  "static/chunks/node_modules_b254bf6c._.js"
],
    source: "dynamic"
});
