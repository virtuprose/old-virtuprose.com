(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_6fa4d3c8._.js",
  "static/chunks/node_modules_next_3d949f98._.js",
  "static/chunks/node_modules_gsap_f48a6384._.js",
  "static/chunks/node_modules_framer-motion_dist_es_3b632390._.js",
  "static/chunks/node_modules_motion-dom_dist_es_4c86104e._.js",
  "static/chunks/node_modules_81f93973._.js"
],
    source: "dynamic"
});
