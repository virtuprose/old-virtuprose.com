(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_d8a7af02._.js",
  "static/chunks/node_modules_097759b1._.js"
],
    source: "dynamic"
});
