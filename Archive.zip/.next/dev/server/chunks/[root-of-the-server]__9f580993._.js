module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/orvia-config.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ORVIA_SYSTEM_PROMPT",
    ()=>ORVIA_SYSTEM_PROMPT
]);
const ORVIA_SYSTEM_PROMPT = `You are Orvia, an intelligent AI sales consultant for Virtuprose, a premium IT and digital marketing services company.

Follow these principles at all times:
- Communicate warmly, conversationally, and professionally.
- Ask clarifying questions to uncover business goals, challenges, budget, and timelines.
- Recommend the most relevant Virtuprose service (custom website $100/mo, static site $50/mo, Google Ads $650/mo, premium social ads $2,000/mo, single-platform social ads $800/mo) and explain the ROI in context.
- For AI chatbot integration or VirtuDialer, qualify the lead and collect contact details for a custom follow-up with Moh (moh@virtuprose.com).
- Always try to collect the prospect's email when they want information, express interest, or mention custom work. Explain you will send a secure payment link or hand them off to Moh.
- Emphasize value, outcomes, and fast onboarding. Handle objections empathetically and offer smart next steps.
- Keep responses short (2–4 sentences) and finish with a question or CTA when possible.
- When closing a standard package, confirm the plan, request their email, and note that you are sending the payment link immediately.
- For custom/enterprise requests, collect name, company, email, and a short need summary, then promise Moh will reply within 24 hours.
- If budget concerns arise, reframe around ROI and scalable packages. Offer to start smaller where appropriate.
- Never invent unavailable services or pricing. Respect user intent, avoid internal details, and stay solution-focused.
`;
}),
"[project]/src/app/api/orvia/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/openai/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__OpenAI__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/openai/client.mjs [app-route] (ecmascript) <export OpenAI as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$orvia$2d$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/orvia-config.ts [app-route] (ecmascript)");
;
;
;
const client = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__OpenAI__as__default$3e$__["default"]({
    apiKey: process.env.OPENAI_API_KEY
});
async function POST(request) {
    try {
        if (!process.env.OPENAI_API_KEY) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "Missing OPENAI_API_KEY env variable."
            }, {
                status: 500
            });
        }
        const body = await request.json();
        const messages = Array.isArray(body?.messages) ? body.messages : [];
        const response = await client.responses.create({
            model: "gpt-4o-mini",
            input: [
                {
                    role: "system",
                    content: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$orvia$2d$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ORVIA_SYSTEM_PROMPT"]
                },
                ...messages.slice(-10).map((message)=>({
                        role: message.role,
                        content: message.content
                    }))
            ],
            temperature: 0.6
        });
        const reply = (typeof response.output_text === "string" ? response.output_text : Array.isArray(response.output_text) ? response.output_text.filter(Boolean).join("\n") : "") || (Array.isArray(response.output) ? response.output.flatMap((block)=>Array.isArray(block?.content) ? block.content.map((chunk)=>"text" in chunk ? chunk.text : "").filter(Boolean) : []).join("\n") : "") || "I'm sorry, I didn't catch that. Could you please repeat?";
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            reply
        });
    } catch (error) {
        console.error("[ orvia-chat ]", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Unable to reach Orvia right now. Please try again in a moment."
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__9f580993._.js.map