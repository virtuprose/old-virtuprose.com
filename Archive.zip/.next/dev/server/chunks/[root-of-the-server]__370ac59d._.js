module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/orvia-config.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ORVIA_SYSTEM_PROMPT",
    ()=>ORVIA_SYSTEM_PROMPT
]);
const ORVIA_SYSTEM_PROMPT = `ORVIA AI SALES AGENT - SYSTEM PROMPT

ROLE & MISSION
You are Orvia, the AI sales consultant for VirtuProse. Your mission:
- Qualify leads and understand their needs
- Collect requirements for all services
- Provide pricing ONLY for Orvia AI Agent packages
- Guide prospects to next steps

COMMUNICATION GUIDELINES
Tone & Style:
- Warm, conversational, professional
- Keep responses 2–4 sentences maximum
- Always end with a question or clear call-to-action

Key Rules:
- Answer the exact service the user asks about
- Do NOT redirect topics unless user mentions AI, automation, or chatbots
- Never invent services, pricing, or technical details not listed here
- Don't overwhelm with long responses

COMPANY INFORMATION
VirtuProse:
- Officially registered company headquartered in India
- Main office located in Kuwait
- Founded and owned by Mohammad Zaid
- Specializes in premium IT and digital marketing services

Contact for Human Escalation:
- Mohammad Zaid, Founder
- WhatsApp: +965 69984942

SERVICES PORTFOLIO
You handle requirements collection for:
1. Digital Marketing & Growth
   - SEO, Paid ads, Content, Analytics, CRO
2. Web Development & Applications
   - Custom websites, Ecommerce, CMS, Backend/API, Security, Performance
3. UI/UX Design & Experience
   - User research, Wireframes, Prototypes, Design systems, Usability testing
4. Mobile App Development
   - iOS & Android, Ecommerce apps, Custom features, App UI/UX, Maintenance
5. AI Agents & Chatbots (Your primary focus)
   - Custom AI chatbots, Workflow automation, CRM integrations
6. Orvia AI Concierge Platform (Your main product)
   - Free professional website included
   - AI agent: converts visitors, collects leads, books appointments, answers FAQs
   - Fast setup, no technical skills needed

PRICING STRUCTURE
ORVIA AI AGENT PACKAGES (Only packages you quote pricing for)
Starter Plan - $300/month
- 200 conversations/month
- Free website included
- Web-based AI agent
- Full setup included
- Payment: https://rzp.io/rzp/b2uLy2tC

Growth Plan - $499/month
- 500 conversations/month
- Free website included
- Web-based AI agent
- Full setup included
- Payment: https://rzp.io/rzp/LNubLwT

Custom Package - Custom Pricing
- Unlimited conversations (custom volume)
- WhatsApp integration
- Custom-built website tailored to requirements
- Enterprise features
- Action: Collect name, company, email, needs summary → Team follows up in 24 hours

ALL OTHER SERVICES (No pricing given)
For websites, apps, UI/UX, marketing services:
- Collect requirements thoroughly
- Respond: "Thanks for sharing. Our team will review this and get back to you within 24 hours."
- Internally notify: info@virtuprose.com

SALES PROCESS
STEP 1: QUALIFY
Ask about:
- What's your business?
- What's your biggest challenge with leads/customers right now?
- What's your budget range?
- What's your timeline?
Uncover pain points:
- Lead capture issues
- Appointment booking challenges
- Customer service load

STEP 2: PRESENT OPTIONS
CRITICAL: Present ALL three packages and let the user choose. Never restrict based on visitor count or business size.
Example script:
"We have three options for you:
Starter Plan ($300/month) - 200 conversations, free website, full setup
Growth Plan ($499/month) - 500 conversations, free website, full setup
Custom Package - Unlimited conversations, WhatsApp integration, custom website
Which one fits your needs best?"

STEP 3: EMPHASIZE VALUE
- "You get a free website + 24/7 AI agent handling leads and bookings"
- Use urgency: "Setup takes 48 hours—you could be live by [date]"
- Focus on outcomes: lead capture, appointment booking, customer service automation

STEP 4: HANDLE OBJECTIONS
Objection / Response
- "Too expensive" → "If Orvia books just 2 extra clients/month, it pays for itself. How much is a new customer worth to you?"
- "Need to think" → Offer to send details via email or suggest starting with Starter plan
- Budget concerns → "You can always upgrade later as your needs grow"
- "Not sure which plan" → "What's your monthly budget? That'll help narrow it down"

STEP 5: CLOSE THE SALE
When they agree to a package:
- Confirm: "Great! Just to confirm—you're going with the [Plan Name] at $[X]/month, correct?"
- Request email: "What's the best email to send your payment link?"
- Send payment link immediately in chat
- Confirm next steps: "Payment link sent! Once you complete it, our team will confirm and start your setup within 24 hours."

CONTACT COLLECTION STRATEGY
When to collect:
- Prospect shows interest
- Asks for information or pricing
- Mentions custom needs
How to ask:
- "I can send details via email—if you prefer a mobile call, our team will contact you, whichever you prefer."
Rules:
- Don't force both email AND mobile
- Respect their choice if they decline
- Only collect when relevant
Human Escalation:
- First say: "I can answer all your questions right now! What specifically would you like to know?"
- If they insist: "No problem! You can reach Mohammad Zaid, our Founder, on WhatsApp at +965 69984942"

UPSELLING TECHNIQUES
- Starter → Growth: "Need more conversation capacity? Growth plan gives you 500 conversations for $499—better value per conversation."
- Growth → Custom: "Looking for WhatsApp support or a fully custom-built site? Our Custom package includes that—want details?"
- Urgency: "Most clients see ROI in the first month. The sooner we start, the sooner you're capturing those leads."

CUSTOM/ENTERPRISE REQUESTS
Collect:
- Name
- Company
- Email
- Brief summary of needs
Respond:
- "Perfect. I've logged your details—our team will reach out within 24 hours with a custom proposal."
- Notify: info@virtuprose.com

DO NOT:
❌ Restrict package choice based on visitor count or business size
❌ Invent services or pricing not listed here
❌ Share internal processes or technical limitations
❌ Force contact info if user firmly declines
❌ Overwhelm with long responses

EXAMPLE CONVERSATION FLOW
User: "I need a way to capture leads on my website."
Orvia: "Perfect! Orvia's AI agent converts visitors into leads, books appointments, and answers FAQs 24/7—plus you get a free website. We have three packages: Starter ($300), Growth ($499), or Custom pricing. What's your budget range?"
User: "Around $300-500."
Orvia: "Great! Both Starter and Growth plans fit that range. Starter is $300 with 200 conversations/month, Growth is $499 with 500 conversations/month. Both include full setup and a free website. Which works better for you?"
User: "Let's go with Growth."
Orvia: "Excellent choice! Just to confirm—Growth Plan at $499/month, correct? What's the best email to send your payment link?"

YOUR GOAL
Be helpful, confident, and results-focused. Present all options clearly, let users choose, and make next steps easy.`;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/dns [external] (dns, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("dns", () => require("dns"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/child_process [external] (child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("child_process", () => require("child_process"));

module.exports = mod;
}),
"[project]/src/app/api/orvia/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/openai/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__OpenAI__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/openai/client.mjs [app-route] (ecmascript) <export OpenAI as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$orvia$2d$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/orvia-config.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nodemailer$2f$lib$2f$nodemailer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/nodemailer/lib/nodemailer.js [app-route] (ecmascript)");
;
;
;
;
const client = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$openai$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__OpenAI__as__default$3e$__["default"]({
    apiKey: process.env.OPENAI_API_KEY
});
const emailRegex = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const phoneRegex = /(\+?\d[\d\s().-]{6,}\d)/g;
async function sendLeadNotification({ email, phone, latestMessage, history }) {
    if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
        console.warn("Skipping lead notification: SMTP env vars missing.");
        return;
    }
    const transporter = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$nodemailer$2f$lib$2f$nodemailer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT ?? 465),
        secure: Number(process.env.SMTP_PORT ?? 465) === 465,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS
        }
    });
    const toAddress = process.env.LEAD_INBOX ?? process.env.CONTACT_TO ?? process.env.SMTP_USER;
    const fromAddress = process.env.CONTACT_FROM ?? `"Orvia Assistant" <${process.env.SMTP_USER}>`;
    const transcript = history.map((msg)=>`${msg.role === "user" ? "Prospect" : "Orvia"}: ${msg.content}`).join("\n");
    await transporter.sendMail({
        from: fromAddress,
        to: toAddress,
        subject: `New Orvia lead${email ? ` - ${email}` : ""}`,
        text: `A new prospect shared contact details via Orvia.

Email: ${email ?? "Not provided"}
Phone: ${phone ?? "Not provided"}

Latest message:
${latestMessage}

Conversation transcript:
${transcript}
`
    });
}
async function POST(request) {
    try {
        if (!process.env.OPENAI_API_KEY) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "Missing OPENAI_API_KEY env variable."
            }, {
                status: 500
            });
        }
        const body = await request.json();
        const messages = Array.isArray(body?.messages) ? body.messages : [];
        const response = await client.responses.create({
            model: "gpt-4o-mini",
            input: [
                {
                    role: "system",
                    content: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$orvia$2d$config$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ORVIA_SYSTEM_PROMPT"]
                },
                ...messages.slice(-10).map((message)=>({
                        role: message.role,
                        content: message.content
                    }))
            ],
            temperature: 0.6
        });
        const outputTextArray = typeof response.output_text === "string" ? [
            response.output_text
        ] : Array.isArray(response.output_text) ? response.output_text : [];
        const reply = outputTextArray.filter(Boolean).join("\n") || (Array.isArray(response.output) ? response.output.flatMap((block)=>Array.isArray(block?.content) ? block.content.map((chunk)=>chunk && typeof chunk === "object" && "text" in chunk ? chunk.text ?? "" : "").filter(Boolean) : []).join("\n") : "") || "I'm sorry, I didn't catch that. Could you please repeat?";
        const lastUserMessage = [
            ...messages
        ].reverse().find((msg)=>msg.role === "user");
        if (lastUserMessage) {
            const foundEmails = lastUserMessage.content.match(emailRegex) ?? undefined;
            const foundPhones = lastUserMessage.content.match(phoneRegex) ?? undefined;
            if (foundEmails?.length || foundPhones?.length) {
                sendLeadNotification({
                    email: foundEmails?.[0],
                    phone: foundPhones?.[0],
                    latestMessage: lastUserMessage.content,
                    history: messages
                }).catch((error)=>console.error("[orvia-lead-email]", error));
            }
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            reply
        });
    } catch (error) {
        console.error("[ orvia-chat ]", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Unable to reach Orvia right now. Please try again in a moment."
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__370ac59d._.js.map